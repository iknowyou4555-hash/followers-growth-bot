import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 3000);
const base = process.env.APP_BASE_URL || `http://localhost:${PORT}`;
const root = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(root,"public")));
app.disable("x-powered-by");

const jobs = [];
const logs = [];
// Demo-ready single-process memory storage. Use encrypted DB + proper session storage for multi-user production.
const tokens = new Map();
const oauthStates = new Map();
const secret = process.env.SESSION_SECRET || "";
const log = (message,type="info") => {
  logs.unshift({id:crypto.randomUUID(),at:new Date().toISOString(),message,type});
  if(logs.length>100)logs.pop();
};
const metaConfigured = () => Boolean(process.env.META_APP_ID && process.env.META_APP_SECRET && process.env.META_REDIRECT_URI && secret.length>=32);
const graphVersion = process.env.META_GRAPH_VERSION || "v26.0";
log("Backend started. Official API mode; no follower injection.", "ok");

app.get("/api/health",(_req,res)=>res.json({ok:true,service:"Followers Growth Bot",uptimeSeconds:Math.floor(process.uptime())}));
app.get("/api/status",(_req,res)=>res.json({
  running:true,
  instagram:{configured:metaConfigured(),connected:tokens.has("local"),mode:"Instagram Login OAuth"},
  tiktok:{configured:false,connected:false,mode:"Not configured"},
  jobs:jobs.length,logs:logs.slice(0,25)
}));

app.post("/api/jobs",(req,res)=>{
  const platform=String(req.body?.platform||"Instagram").slice(0,40);
  const niche=String(req.body?.niche||"general").slice(0,100);
  const count=Math.max(1,Math.min(14,Number(req.body?.postsPerWeek)||4));
  const target=Math.max(1,Math.min(1_000_000_000,Number(req.body?.target)||1000));
  const job={id:crypto.randomUUID(),platform,niche,postsPerWeek:count,target,status:"completed",createdAt:new Date().toISOString(),
    result:[
      `Platform: ${platform}`,`Topik akun: ${niche}`,`Target followers: ${target.toLocaleString("id-ID")}`,
      `Jadwalkan ${count} konten berkualitas per minggu.`,
      "Uji beberapa format dan pantau jangkauan, waktu tonton, simpanan, bagikan, dan komentar.",
      "Tinjau statistik mingguan dan sesuaikan strategi."
    ],
    note:"Job ini dijalankan backend. Tidak menambahkan followers palsu."
  };
  jobs.unshift(job);if(jobs.length>50)jobs.pop();log(`Job rencana konten dibuat untuk ${platform}.`,"ok");res.status(201).json(job);
});
app.get("/api/jobs",(_req,res)=>res.json({jobs}));
app.get("/api/logs",(_req,res)=>res.json({logs}));

// Instagram Login OAuth with state validation. Requires a real Meta app and matching redirect URI.
app.get("/auth/instagram",(req,res)=>{
  if(!metaConfigured()){log("Instagram OAuth belum dikonfigurasi.","warn");return res.status(501).send("Belum dikonfigurasi. Isi META_APP_ID, META_APP_SECRET, META_REDIRECT_URI, dan SESSION_SECRET di .env. Jangan kirim secret ke siapa pun.");}
  const state=crypto.randomBytes(32).toString("hex");
  const mac=crypto.createHmac("sha256",secret).update(state).digest("hex");
  oauthStates.set(state,{mac,expires:Date.now()+10*60*1000});
  const q=new URLSearchParams({
    client_id:process.env.META_APP_ID,
    redirect_uri:process.env.META_REDIRECT_URI,
    response_type:"code",
    scope:process.env.META_SCOPES||"instagram_business_basic,instagram_business_manage_insights",
    state
  });
  res.redirect(`https://www.instagram.com/oauth/authorize?${q.toString()}`);
});

app.get("/auth/instagram/callback",async(req,res)=>{
  const {code,state,error}=req.query;
  if(error){log("Login Instagram dibatalkan atau ditolak.","warn");return res.status(400).send("Login Instagram dibatalkan atau izin ditolak.");}
  const entry=oauthStates.get(String(state||""));
  oauthStates.delete(String(state||""));
  if(!code||!entry||entry.expires<Date.now()){return res.status(400).send("OAuth state tidak valid atau sudah kedaluwarsa. Coba hubungkan lagi.");}
  const expected=crypto.createHmac("sha256",secret).update(String(state)).digest("hex");
  if(!crypto.timingSafeEqual(Buffer.from(entry.mac),Buffer.from(expected)))return res.status(400).send("Validasi OAuth gagal.");
  try {
    const form=new URLSearchParams({
      client_id:process.env.META_APP_ID,
      client_secret:process.env.META_APP_SECRET,
      grant_type:"authorization_code",
      redirect_uri:process.env.META_REDIRECT_URI,
      code:String(code)
    });
    const tokenResponse=await fetch("https://api.instagram.com/oauth/access_token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:form});
    const short=await tokenResponse.json();
    if(!tokenResponse.ok||!short.access_token)throw new Error(short.error_message||short.error?.message||"Code exchange gagal.");
    const longUrl=new URL("https://graph.instagram.com/access_token");
    longUrl.search=new URLSearchParams({grant_type:"ig_exchange_token",client_secret:process.env.META_APP_SECRET,access_token:short.access_token});
    const longResponse=await fetch(longUrl);
    const long=await longResponse.json();
    if(!longResponse.ok||!long.access_token)throw new Error(long.error?.message||"Long-lived token exchange gagal.");
    const meUrl=new URL(`https://graph.instagram.com/${graphVersion}/me`);
    meUrl.search=new URLSearchParams({fields:"user_id,username,account_type,media_count,followers_count,follows_count",access_token:long.access_token});
    const meResponse=await fetch(meUrl);
    const me=await meResponse.json();
    if(!meResponse.ok||!me.user_id)throw new Error(me.error?.message||"Tidak dapat membaca profil. Periksa scopes dan versi API.");
    tokens.set("local",{accessToken:long.access_token,expiresIn:Number(long.expires_in||0),savedAt:Date.now(),profile:me});
    log(`Instagram account @${me.username||"connected"} terhubung via OAuth.`,"ok");
    res.redirect("/?connected=instagram");
  } catch(e) {
    log(`OAuth gagal: ${String(e.message).slice(0,180)}`,"error");
    res.status(502).send(`Koneksi Instagram gagal: ${String(e.message).slice(0,300)}. Periksa app settings, scopes, redirect URI, dan akun profesional.`);
  }
});

app.get("/api/instagram/profile",async(_req,res)=>{
  const session=tokens.get("local");
  if(!session)return res.status(401).json({error:"Instagram belum terhubung. Tekan Hubungkan Instagram."});
  try {
    const u=new URL(`https://graph.instagram.com/${graphVersion}/me`);
    u.search=new URLSearchParams({fields:"user_id,username,account_type,media_count,followers_count,follows_count",access_token:session.accessToken});
    const r=await fetch(u);const d=await r.json();
    if(!r.ok)throw new Error(d.error?.message||"Graph API request failed");
    session.profile=d;
    res.json({profile:d,tokenExpiresIn:session.expiresIn,note:"Data aktual dari API untuk akun yang diotorisasi."});
  }catch(e){res.status(502).json({error:String(e.message).slice(0,200)});}
});
app.post("/api/instagram/disconnect",(_req,res)=>{tokens.delete("local");log("Token Instagram lokal dihapus dari memori.","ok");res.json({ok:true});});
app.get("/auth/tiktok",(_req,res)=>res.status(501).send("TikTok OAuth belum disiapkan. Buat aplikasi di TikTok for Developers dan implementasikan produk/scope resmi yang disetujui."));
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:"Internal server error"});});
app.listen(PORT,()=>console.log(`Followers Growth Bot running at ${base}`));
