# Followers Growth Bot v3

## Run
1. Install Node.js 18+ on a Node host or computer.
2. Extract ZIP, run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add credentials from your own Meta developer app and set an exact registered redirect URI.
5. Set a random `SESSION_SECRET` with 32+ characters.
6. Run `npm start`, then open `http://localhost:3000`.

## Instagram OAuth
This version implements an Instagram Login OAuth code exchange, long-lived token exchange, state validation, and a profile API request. It requires a real configured Meta app, correct product/scopes, redirect URI, eligible professional account, and any review/permissions Meta requires. OAuth/API versions and scope availability can change; confirm them in your Meta developer dashboard.

## API routes
- `GET /api/health`
- `GET /api/status`
- `POST /api/jobs`
- `GET /api/instagram/profile`
- `POST /api/instagram/disconnect`
- `GET /auth/instagram`

## Important production work
Tokens are held in process memory for this single-user starter and disappear on restart. Before public/multi-user deployment, implement secure server-side sessions, per-user token storage encrypted at rest, CSRF protection for app routes, rate limiting, HTTPS, token refresh/expiry/revocation, privacy policy, deletion, monitoring, and Meta App Review where needed. Never put app secret or access tokens in frontend code or public repos.

Official platform APIs support authorized account management and metrics, not arbitrary addition of fake followers. No fake follower injection feature is implemented.
